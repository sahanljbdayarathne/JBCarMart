// Select elements
const modal = document.getElementById("signup-modal");
const openBtn = document.getElementById("btn-open-signup");
const closeEls = document.querySelectorAll("[data-close]");
const oauthBtns = document.querySelectorAll(".oauth-btn");

// Open modal
openBtn.addEventListener("click", (e) => {
  e.preventDefault();
  modal.setAttribute("aria-hidden", "false");
});

// Close modal
closeEls.forEach((el) =>
  el.addEventListener("click", () => {
    modal.setAttribute("aria-hidden", "true");
  })
);

// ===== Popup Simulation =====
function startOAuth(provider) {
  // TEMP popup until your WP OAuth routes are added
  let popup = window.open(
    "",
    "oauthPopup",
    "width=500,height=600,left=300,top=100"
  );

  popup.document.write(`
    <h2 style="font-family: sans-serif;">${provider.toUpperCase()} Login</h2>
    <p>This simulates the OAuth popup. Replace with real OAuth URL later.</p>
    <button onclick="window.opener.postMessage({success: true, provider: '${provider}'}, '*'); window.close();"
      style="padding: 10px 20px; margin-top: 20px; cursor:pointer;">Complete Login</button>
  `);
}

// Listen for finish from popup
window.addEventListener("message", (event) => {
  if (event.data?.success) {
    alert("Login successful via " + event.data.provider);
    modal.setAttribute("aria-hidden", "true");
  }
});

// Start OAuth when clicking a button
oauthBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    const provider = btn.getAttribute("data-provider");
    startOAuth(provider);
  });
});
